/*
 Simulation/comparison of ILIGRA/ROUSSOPOULOS/LEHOT/DEGIORGI

 C++ implementation: S. Trajanovski

 @ Network Architecture and Services group, Faculty of El. Engineering Mathematics and Computer Science
   Delft University of Technology
   The Netherlands
*/

#include <LEDA/system/msc/autolink_static.h>
#include <LEDA/graph/graph.h>
#include <LEDA/graph/graph_gen.h>
#include <LEDA/graph/ugraph.h>
#include <LEDA/graph/node_data.h>
#include <LEDA/core/array.h>
#include <LEDA/graph/node_list.h>
#include <LEDA/graph/node_set.h>
#include <LEDA/graph/edge_set.h>
#include <LEDA/graph/node_matrix.h>
#include <LEDA/system/basic.h>
#include <LEDA/core/random.h>
#include "common.cpp"
#include "roussopoulos.cpp"
#include "lehot.cpp"
#include "degiorgi.cpp"
#include "iligra.cpp"

static void generateErdosRenyiRandomGraph(int N, double p, GRAPH<int,int>& G)
{

	node n, n1;
	random_source rnd;
	int q, w;

	for(int i = 0; i<N; i++)
		G.new_node(i);

	forall_nodes(n,G)
		forall_nodes(n1,G)
			if(p > ((double)rand())/(RAND_MAX+1))
			{
				q = G.index(n);
				w = G.index(n1);

				if(q>w)
				{
					G.new_edge(n,n1);
					G.new_edge(n1,n);
				}
			}

	//G.print();
}

static double rndm(int& n)
{
	return ((double)n)*(((double)rand())/(RAND_MAX+1));
}

static void generateWattsStrogatsRandomGraph(int N, double k, double p, GRAPH<int,int>& G)
{
	node n, n1;
	random_source rnd;
	int q, w;

	int added = 0;
	double links = k * N / 2 ;
	int round = 1;
	int src=0, dst=1;
	array<node> map(N);
	node m;

	for(int i = 0; i<N; i++)
	{
		m = G.new_node(i);
		map[i] = m;
	}

	node src_node, dst_node;

	src_node = map[0];
	dst_node = map[1];
		
	// Moving clockwise, we add a link between a node and its @(round+1)'th hop neighbour
	// until the average degree condition is fulfilled.
	// For example, in round 1 we start with 0-1, then 1-2, then 2-3.
	// In round 2 we continue with link 0-2, then 1-3, then 2-4, etc.
	while(added < links) {
		if (((double)rand())/(RAND_MAX+1) < p){ // With probability p, rewire the link instead of regularly adding it

			//edge e =G.
			while(src==dst || G.adj_nodes(src_node).search(dst_node)){//containsLink(src, dst)
				src = rndm(N);
				dst = rndm(N);
				src_node = map[src];
				dst_node = map[dst];
			}

		}
		else { // With probability 1-p, add a ring as if the graph was a standard ring.
			dst = (src + round) % N;
			src_node = map[src];
			dst_node = map[dst];
		}
				
		// System.out.println("Adding link "+src+","+dst);
		if(!G.adj_nodes(src_node).search(dst_node))
			G.new_edge(src_node,dst_node);
			
		src = (src+1)%N;
		added++;
			
		// Now the jumps will be 1 node larger.
		if(added % N==0)
			round++;
	}
}

static void LINE_GRAPH_GENERATOR(GRAPH<int,int>& G, GRAPH<int,int>& H)
{
	int i, j, n;
	edge e, e1;
	node x, y, u, v, z;

	edge_array<node> root_edge_gives_line_graph_node;//(G);
	root_edge_gives_line_graph_node.init(G);

	edge_array<edge> reverse_edge;//(G);
	reverse_edge.init(G);
	
	forall_edges(e,G)
	{
		x = G.source(e);
		y = G.target(e);

		forall_adj_edges(e1,y)
			if(G.target(e1) == x)
			{
				reverse_edge[e1] = e;
				reverse_edge[e] = e1;
			}
	}

    /* the reverse edge for each edge is found; the complexity is: O(|E(line_graph)|) */
	n = 0;
	
	forall_edges(e,G)
	{
		y = G.source(e);
		z = G.target(e);

		i = G.index(y);
		j = G.index(z);
		
		if(i<j)
		{
			x = H.new_node(n);
			n++;
			root_edge_gives_line_graph_node[e] = x;
			e1 = reverse_edge[e];

			root_edge_gives_line_graph_node[e1] = x;     
		}
	}

    /* for each (undirected) edge is a node created; the correspondence is saved in the edge_array(node) "root_edge_gives_line_graph_node" */
    /* Create the edges of the line graph: again, the complexity is: O(|E(line_graph)|) */ 
	
	forall_edges(e,G)
	{
		x = G.source(e);
		
		forall_adj_edges(e1,x)

		if(e1 != e)
		{
			u = root_edge_gives_line_graph_node[e]; /* "u" is the line graph node which corresponds to the root edge "e" */
			v = root_edge_gives_line_graph_node[e1]; /* "v" is the line graph node which corresponds to the root edge "e1" */

			//G.print_node(u);
			//G.print_node(v);

			H.new_edge(u,v);
		}
	}
  /* the line graph of the root graph "root" is now created;
     the total complexity is: O(|E(line_graph)|)  */
} /* end LINE_GRAPH_GENERATOR ... */

static void printLineGraphState(bool& is_LG, GRAPH<int,int>& LG)
{
   if(is_LG)
   {
    cout<<endl;
	cout<<endl;
    cout << " the graph is a line_graph! ";
    cout<<endl;
	cout<<endl;
    cout << " the root has ";
    cout << LG.number_of_nodes() << " nodes and ";
    cout << LG.number_of_edges()/2 << " edges. ";
    cout<<endl;
	cout<<endl;

    if(Yes(" show the root ? ")) 
    {
       cout << " the root is:";
       cout<<endl;
	   cout<<endl;
       LG.print();
       cout<<endl;
	   cout<<endl;
    }
   }
   else
   {
       cout<<endl;
	   cout<<endl;
       cout << " the graph is not a line graph! ";
       cout<<endl;
	   cout<<endl;
   }
}

static bool readNetwork(char* nameFile, GRAPH<int,int>& gr)
{
   char str[200];
   FILE *fp;
   int fst, scnd;
   list<int> nods;
   node it, n1, n2;
 
   fp = fopen(nameFile, "r");
   if(!fp) return false; // bail out if file not found

   while(fgets(str,sizeof(str),fp) != NULL)
   {
      // strip trailing '\n' if it exists
      int len = strlen(str)-1;
      if(str[len] == '\n') 
         str[len] = 0;

	  char* token = strtok(str, " ");

	  fst = atoi(token);
	  token = strtok(NULL, " ");
	  scnd = atoi(token);


	  if(!nods.search(fst))
	  {
		  n1 = gr.new_node(fst);
		  nods.append(fst);
	  }
	  else
	  {
		  forall_nodes(it, gr)
			  if(gr.inf(it)==fst)
			  {
				  n1 = it;
				  break;
			  }
	  }

	  if(!nods.search(scnd))
	  {
		  n2 = gr.new_node(scnd);
		  nods.append(scnd);
	  }
	  else
	  {
		  forall_nodes(it, gr)
			  if(gr.inf(it)==scnd)
			  {
				  n2 = it;
				  break;
			  }
	  }

	  gr.new_edge(n1,n2);

   }

   gr.make_bidirected();
   fclose(fp);
   return true;
}

static void writeNetwork(char* nameNetwork, GRAPH<int,int> gr)
{
   FILE *fl; 
   fl = fopen(nameNetwork,"w"); /* apend file (add text to a file or create a file if it does not exist.*/
   edge e;

   forall_edges(e,gr)
	   if(gr.inf(gr.source(e)) < gr.inf(gr.target(e)))
			fprintf(fl, "%d %d\n",gr.inf(gr.source(e)), gr.inf(gr.target(e)));

   fclose(fl); /*done!*/ 
}


int main()
{ 
  int k; 

  int NumIter = 100;

  FILE *fi; 
  fi = fopen("outputData//NonLineGraph_dens_65.txt","w"); /* apend file (add text to a file or create a file if it does not exist.*/

  int links[21] = {200, 350, 500, 650, 800, 1000, 1250, 1500, 2000, 2500, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 12000, 15000, 17500};
  cout << "nodes\t" << "edges\t" << "density\t" <<"Roussopoulos\t" << "Lehot\t" << "Degiorgi\t"<< "NAS\t" << endl;

  for(int k=0; k<21; ++k)
  {
	float cumulRouss, cumulLehot, cumulDegiorgi, cumulNAS;
	cumulRouss = cumulLehot = cumulDegiorgi = cumulNAS = 0;

	char buf[6];
	char name[45] = "inputGraphs//NonLineGraph_dens_65//NonLG_";
	itoa(links[k],buf,10);
	strcat(name, buf);
	strcat(name, "_");
    itoa(65,buf,10);
	strcat(name, buf);

	GRAPH<int,int> G, H;
	readNetwork(name,H);


	int i, j, n, m;
	edge e, e1, e2;
	node x, y, u, v, z;

	bool is_a_line_graph = false;
	node start_node;

	GRAPH<int,int> H1(H);
	GRAPH<int,int> H2(H);
	GRAPH<int,int> H3(H);
	GRAPH<int,int> H4(H);
	GRAPH<int,int> H5(H);

	for(int r = 0; r<NumIter; r++)
	{
		
		GRAPH<int,int> root, root1, root2, root3, root4, root5;

		float Time, TimeRoussopoulos, TimeLehot, TimeDegiorgi, TimeNAS, TimeLehot_WO;

		// Roussopoulos' algorithm
		is_a_line_graph = false;
		start_node = H1.first_node();
		/*  Time counts from here. */
		Time = used_time();
		ROUSSOPOULOS(H1, start_node, is_a_line_graph, root1);
		TimeRoussopoulos = 1000.0*used_time(Time);

		// Lehot's algorithm
		is_a_line_graph = false;
		start_node = H2.first_node();
		/*  Time counts from here. */
		Time = used_time();
		LEHOT(H2, start_node, is_a_line_graph, root2);
		TimeLehot = 1000.0*used_time(Time);
	  
		// Degiorgi's algorithm
		is_a_line_graph = false;
		start_node = H3.first_node();
		Time = used_time();
		DEGIORGI(H3, start_node, is_a_line_graph, root3);
		TimeDegiorgi = 1000.0*used_time(Time);

		// NAS algorithm
		is_a_line_graph = false;
		start_node = H4.first_node();
		Time = used_time();
		NAS(H4, start_node, is_a_line_graph, root4);
		TimeNAS = 1000.0*used_time(Time);
		
		cumulRouss += TimeRoussopoulos;
		cumulLehot += TimeLehot;
		cumulDegiorgi += TimeDegiorgi;
		cumulNAS += TimeNAS;		
	}

	cumulRouss /= NumIter;
	cumulLehot /= NumIter;
	cumulDegiorgi /= NumIter;
	cumulNAS /= NumIter;

	cout << H.number_of_nodes() << "\t" << H.number_of_edges()/2 << "\t"<< (((double)H.number_of_edges())/H.number_of_nodes())/(H.number_of_nodes()-1) << "\t" << cumulRouss << "\t\t" << cumulLehot << "\t"  << cumulDegiorgi << "\t\t" << cumulNAS << endl;//
	fprintf(fi, "%d\t%d\t%f\t%f\t%f\t%f\n", H.number_of_edges()/2, links[k], cumulRouss, cumulLehot, cumulDegiorgi, cumulNAS);
  }

  fclose(fi); /*done!*/ 

  cin>>k;
  return 0;
} 
