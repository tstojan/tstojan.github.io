/*
 "ILIGRA: An Efficient Inverse Line Graph Construction Algorithm" 
 authors: Dajie Liu, Stojan Trajanovski, Piet Van Mieghem

 C++ implementation: S. Trajanovski

 @ Network Architecture and Services group, Faculty of El. Engineering Mathematics and Computer Science
   Delft University of Technology
   The Netherlands
*/

#include <LEDA/graph/graph.h>
#include <LEDA/graph/node_data.h>
#include <LEDA/core/array.h>
#include <LEDA/core/array2.h>
#include <LEDA/graph/node_array.h>
#include <LEDA/core/d_array.h>
#include <LEDA/graph/node_set.h>
#include <LEDA/graph/edge_set.h>
#include <LEDA/graph/node_matrix.h>
#include <LEDA/system/basic.h>
#include "common.cpp"

/* the function move a node from the original graph after it has been processed: 
   1) from non-examined to half-examined (both 'open' nodes to one 'open' node)
   2) from half-examined to examined (one 'open' node to 'resolved' node) */

static void transferNodes(node& n1, list<node>& non, list<node>& half)
{
	non.remove(n1);
	half.append(n1);
}

/* the function checks the INITIAL pair-wise connetivity between the nodes in the list neigh in the graph h_gr. For a real line graph they must form:
    (a) full mesh OR
	(b) one node is not connected to none of the the other nodes in neigh and the remaining nodes form a full mesh OTHERWISE 
	the input cannot be a line graph.

	Additionally, in the case (n) Neigh(u)\{n1,n2} = Neigh(n1)\Neigh(n2) union Neigh(n2)\Neigh(n1)
	
	if (a) all the nodes are assigned to already created node f in G - 'adjacent to n1 and n2'
	if (b) 'this node' is assigned to already created node s in G - 'adjacent to n1, but not to n2' and the remaining nodes are assigned to f. */



static bool findConnectivity(list<node>& neigh, GRAPH<int,int>& h_gr, d_array<node,node>& ls, node f, node s)
{
	list<node> t1(neigh), tst;
	node nd1, nd2, uniq = NULL;
	int count = 0;
	int total = neigh.size();
	bool full = true;

	if(neigh.empty())
		return true;

	nd1 = neigh.front();
	tst = h_gr.adj_nodes(nd1);
	count = 0;

	forall(nd2,neigh)
		if((nd1!=nd2)&&(tst.search(nd2)))
			count++;
		else
			uniq = nd2;

	if(count==0)
	{
		uniq = nd1;
		full = false;
	}
	else if(count==(total-1))
		full = true;
	else if(count==(total-2))
		full = false;
	else
		return false;

	forall(nd1,neigh)
	{
		tst = h_gr.adj_nodes(nd1);
		count = 0;

		forall(nd2,t1)
			if((nd1!=nd2)&&(tst.search(nd2)))
				count++;

		if((full&&(count<(total-1))))
			return false;
		else if(((!full)&&(nd1!=uniq)&&(count<(total-2))))
			return false;
		else if(((!full)&&(nd1==uniq)&&(count>0)))
			return false;
	}

	if(!full)
	{
		ls.insert(uniq,s);
		t1.remove(uniq);
	}

	forall(nd2,t1)
		ls.insert(nd2,f);

	return true;
}

/* The function checks if the node nd is connected to all the nodes from the list l in the graph gr (H in our case) */

static bool connectivity(node nd, list<node>& l,  GRAPH<int,int>& gr)
{	
	node f;
	list<node> tst = gr.adj_nodes(nd);

	forall(f,l)
		if(!tst.search(f))
			return false;

	return true;
}


static void NAS(GRAPH<int,int>& H, 
                  node& n1,
                  bool& is_a_line_graph, 
                  GRAPH<int,int>& G) 
{
  //generalLineGraph general;
  /* "H" is possibly a line graph, "G" becomes its root graph */

  node n_x, a, b, newNode, n_k, n_iter;
  int M = 1, num_nod, k;
  int N_h = H.number_of_nodes();
  array<node> n(N_h+1);
  d_array<node, node> lst;
  list<node> halfExamined, nonExamined, neighbourhood, neighbourhood_ij, newAdded, potetntial;


  is_a_line_graph = false;

  if(H.degree(n1) == 0) 
  {
    is_a_line_graph = true;
    a = G.new_node(0);
    b = G.new_node(1);
    G.new_edge(a,b);
    G.new_edge(b,a);
    return;
  }

  
  /* all the nodes are not examined (both open nodes) at the beginning */
  nonExamined = H.all_nodes();
  
  n[1] = n1;

  forall_adj_nodes(n_x,n1,H)
  {
	 M++;
	 n[M] = n_x;
  }


  /* except the initial node n1.. one link with endnodes a and b is created in G*/
  nonExamined.remove(n[1]);

  a = G.new_node(1);
  b = G.new_node(2);
  G.new_edge(a,b);

  /* one neighbour of the initial (n2) is half examined */
  lst.insert(n[2],a);
  transferNodes(n[2], nonExamined, halfExamined);

  neighbourhood_ij.append(n[1]);
  neighbourhood_ij.append(n[2]);

  forall_adj_nodes(n_x,n[2],H)
  {
	 if((!H.adj_nodes(n[1]).search(n_x)))
			neighbourhood_ij.append(n_x);
  }

  /* the nodes adjecent to n1 but not n2 */
  if(M==3)
  {
	lst.insert(n[3],a);
	transferNodes(n[3], nonExamined, halfExamined);
  }
  else
  {
	for(int T = 3; T<=M; T++)
	{
		if((!H.adj_nodes(n[2]).search(n[T])))
		{
			potetntial.append(n[T]);
			lst.insert(n[T],b);
			neighbourhood_ij.append(n[T]);
		}
		else
			neighbourhood.append(n[T]);

		transferNodes(n[T], nonExamined, halfExamined);	
	}
	
	k = 0;
	/* Neigh(u)\{n1,n2} = Neigh(n1)\Neigh(n2) union Neigh(n2)\Neigh(n1) */

	forall(n_x, potetntial)
		if(neighbourhood_ij==H.adj_nodes(n_x))
		{
			k++;
			lst.insert(n_x,b);
			if(k>1)
				return;
		}

	/* those adjacent by n1 and n2 in H are examined in findConnectivity */
	if(!findConnectivity(neighbourhood, H, lst, a, b))
		return;
  }

  num_nod = 2;

  /* we iterate through the members of half examined nodes n_k and a new node in G is created. This node is connected with the assigned to n_k in G.
  From the neighbours of n_k in H, if they are half examined and assigned to the different node in G the link is established between the new nodes in G
  and the assigned node to the neigbour; if they are not examined we assign n_k to that nodes and they become half-examined. 
  The connctivity check is done to n_k's new and potential links  to be pair-wise connected in testConn */

  while(!halfExamined.empty())
  {		
	n_k = halfExamined.pop();
	newAdded.clear();

	num_nod++;
	newNode = G.new_node(num_nod);		
	G.new_edge(lst[n_k],newNode);

	forall_adj_nodes(n_iter,n_k)//,H)
	{
		if(halfExamined.search(n_iter))
		{
			if(lst[n_iter]!=lst[n_k])
			{
				G.new_edge(lst[n_iter],newNode);
				halfExamined.remove(n_iter);

				if(connectivity(n_iter,newAdded,H))
					newAdded.append(n_iter);
				else
					return;			
			}
		}
		else if(nonExamined.search(n_iter))
		{
			lst.insert(n_iter,newNode);
			transferNodes(n_iter,nonExamined,halfExamined);

			newAdded.append(n_iter);

			if(connectivity(n_iter,newAdded,H))
					newAdded.append(n_iter);
				else
					return;
		}
	}
  }

  G.make_bidirected();
  is_a_line_graph = true;
}