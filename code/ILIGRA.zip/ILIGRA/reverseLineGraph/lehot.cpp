/* 
   This is an implementation of an algorithm due to Philippe G. H. Lehot
   to detect line graphs, described in the 
     JOURNAL OF THE ASSOCIATION FOR COMPUTING MACHINERY,
     Vol. 21, No. 4, October 1974, pp. 569-575

   "An Optimal Algorithm to Detect a Line Graph and Output Its Root Graph"

   Implementation by Hans-Peter Schmocker, III C/Diplomsemester, ETH Zurich.
   Date: 10.January 1991


   Remark: the hint "STEP i" in the comments of the program refers to 
           i'th step in the algorithm of the paper.
*/

#include <LEDA/graph/graph.h>
#include <LEDA/graph/node_data.h>
#include <LEDA/core/array.h>
#include <LEDA/core/array2.h>
#include <LEDA/graph/node_set.h>
#include <LEDA/graph/edge_set.h>
#include <LEDA/graph/node_matrix.h>
#include <LEDA/system/basic.h>
#include "common.cpp"

/* 
   the boolean procedure "odd_triangle_Lehot" is used to check if a given 
   triangle is odd by testing if there is a certain node in exactly
   1 adjacenzy list of the 3 adjacenzy lists or in all 3.
*/

static bool odd_triangle_Lehot(list<node> &list1, list<node> &list2, list<node> &list3,
                  node_set &set1, node_set &set2, node_set &set3)
{
  node x;
  forall(x,list1)
    if(!set2.member(x) && !set3.member(x))
      return true;

  forall(x,list2)
    if(!set1.member(x) && !set3.member(x))
      return true;

  forall(x,list3)
    if(!set1.member(x) && !set2.member(x))
      return true;

  forall(x,list1)
    if(set2.member(x) && set3.member(x))
      return true;

  return false;
}


static void LEHOT(GRAPH<int,int>& line_graph, 
           node& start_node,
           bool& is_a_line_graph, 
           GRAPH<int,int>& root)
{

  //generalLineGraph general;
  bool is_an_odd_triangle;

  node u, v, w, x, y, half_named_node,
	  fully_named_node, basic_node1, basic_node2;

  node cross_node;
  memset( &cross_node, 0, sizeof(node) );
  

  //*cross_node = new node;

  //cross_node = start_node;

  edge e, e1;

  list_item list_it;

  node_array<int> first_number(line_graph,0),
                  second_number(line_graph,0);

  node_set fully_named_nodes(line_graph),
           half_named_nodes(line_graph),
           unnamed_nodes(line_graph),
           adj1_set(line_graph), adj2_set(line_graph);

  list<node> adj_nodes_list, 
           adj1_list, adj2_list,
           naming_nodes; 

  node_array<node> half_named_from(line_graph,0);

  /* introduced to ease the choice of the two new basic nodes in 
     the main step. 
     "half_named_from[half_named_node] gives the one adjacent, fully named
      node which half_named the half_named_node. Everything ok ?
  */

  int clique_number;
  int nr_nodes = line_graph.number_of_nodes();
  int nr_edges = line_graph.number_of_edges();
  
  /* "clique_number" is the number of cliques we know at the moment */

  /* STEP 1. Pick up two adjacent nodes. Name them 1-2 and 2-3.
             They are the two basic nodes to start with:
  */

  forall_nodes(x,line_graph) unnamed_nodes.insert(x);
  basic_node1 = start_node;

  /* the trivial graph (one node, zero edges) is considered as a line graph: 
     (to prevent segmentation faults)
  */
  if(line_graph.indeg(basic_node1) == 0) 
  {
    is_a_line_graph = true;
    v = root.new_node(0);
    w = root.new_node(1);
    root.new_edge(v,w);
    root.new_edge(w,v);
    return;
  }
   e = line_graph.first_adj_edge(basic_node1);
  basic_node2 = line_graph.target(e);
  
  unnamed_nodes.del(basic_node1);
  unnamed_nodes.del(basic_node2);

  fully_named_nodes.insert(basic_node1);
  fully_named_nodes.insert(basic_node2);

  first_number[basic_node1] = 2;
  second_number[basic_node1] = 1;

  first_number[basic_node2] = 2;
  second_number[basic_node2] = 3;

  clique_number = 3;

  naming_nodes.append(basic_node1);
  naming_nodes.append(basic_node2);

  /* 
     the nodelist "naming_nodes" contains all nodes of the current clique
     ( == clique 2) which are allowed to half_name the adjacent nodes of 
     the clique. the cross_node is NOT a member of "naming_nodes"! 
  */

  /* STEP 2. Find all nodes which are adjacent to both "basic_nodes": */ 

  adj1_list = line_graph.adj_nodes(basic_node1);
  adj2_list = line_graph.adj_nodes(basic_node2);
  forall(x,adj1_list) adj1_set.insert(x);
  forall(x,adj2_list)
  {
    adj2_set.insert(x);
    if(adj1_set.member(x))
      adj_nodes_list.append(x);    
  } /* end forall(x,adj2-list) ...   */

  /* "adj_nodes_list" is now the list containing all nodes adjacent to 
     both "basic_nodes"  
  */

  int len = adj_nodes_list.length();
  
  if(len == 1)
  {
    /* 
       STEP 3. There is only one node adjacent to both "basic_nodes"
               Call this node "x". 
               If the triangle (x, basic_node1, basic_node2) is odd
               (there exist a node which is adjacent only to one of the
               three nodes), then "x" is 2-4, else "x" is the cross_node 1-3.
   */

    list<node> x_list;
    node_set x_set(line_graph);

    is_an_odd_triangle = false;
    list_it = adj_nodes_list.first();
    x = adj_nodes_list.contents(list_it);
    x_list = line_graph.adj_nodes(x);
    forall(y,x_list) x_set.insert(y);
    if(odd_triangle_Lehot(adj1_list,adj2_list,x_list,adj1_set,adj2_set,x_set))
    {
      first_number[x] = 2;
      second_number[x] = 4;
      clique_number = 4;
      naming_nodes.append(x);
    }
    else
    {
      first_number[x] = 1;
      second_number[x] = 3;
      cross_node = x;
    }
    fully_named_nodes.insert(x);
    unnamed_nodes.del(x);
  } /* end if(len == 1) ... */

  if(len == 2)
  { 
    /* 
       STEP 4. There are two nodes adjacent to both "basic_nodes".
               Call them "x" and "y". If "x" and "y" are adjacent, then
               there is no cross_node. Name "x" with 2-4 and "y" with 2-5.
   */
    bool adjacent = false;
    list_it = adj_nodes_list.first();
    x = adj_nodes_list.contents(list_it);
    list_it = adj_nodes_list.last();
    y = adj_nodes_list.contents(list_it);
    forall_adj_nodes(w,x) if(w == y) adjacent = true;
    if(adjacent)
    {
      first_number[x] = 2;
      second_number[x] = 4;
      fully_named_nodes.insert(x);
      unnamed_nodes.del(x);
       
      first_number[y] = 2;
      second_number[y] = 5;
      fully_named_nodes.insert(y);
      unnamed_nodes.del(y);

      clique_number = 5;
      naming_nodes.append(x);
      naming_nodes.append(y);
    } /* end if(adjcent) ... */
    else
    { 
      /* 
         Check the two triangles (x, basic_node1, basic_node2) and
         (y, basic_node1, basic_node2). If one of them is odd, the 
         corresponding summit, say "x", is 2-4, and the other one,
         "y", is 1-3, the cross_node;
         else both triangles are even: there are only three remaining
         possibilities, as shown in Figure 5, page 574 of Lehot's paper.
      */
      list<node> x_list, y_list;
      node_set x_set(line_graph), y_set(line_graph);
      x_list = line_graph.adj_nodes(x);
      forall(w,x_list) x_set.insert(w);
      
      if(odd_triangle_Lehot(adj1_list,adj2_list,x_list,adj1_set,adj2_set,x_set))
      {  
        cross_node = y;
        first_number[x] = 2;
        second_number[x] = 4;
        first_number[y] = 1;
        second_number[y] = 3;
        fully_named_nodes.insert(x);
        unnamed_nodes.del(x);
        fully_named_nodes.insert(y);
        unnamed_nodes.del(y);
        naming_nodes.append(x);
        clique_number = 4;
      }
      else
      {
        y_list = line_graph.adj_nodes(y);
        forall(w,y_list) y_set.insert(w);
        if(odd_triangle_Lehot(adj1_list,adj2_list,y_list,adj1_set,adj2_set,y_set))
        {
          cross_node = x;
          first_number[x] = 1;
          second_number[x] = 3;
          first_number[y] = 2;
          second_number[y] = 4;
          fully_named_nodes.insert(x);
          unnamed_nodes.del(x);
          fully_named_nodes.insert(y);
          unnamed_nodes.del(y);
          naming_nodes.append(y);
          clique_number = 4;
        }
        else
        {
          node node1, node2, node3, node4;
          node1 = root.new_node();
          node2 = root.new_node();
          node3 = root.new_node();
          node4 = root.new_node();
          
          if(nr_nodes == 4)
          {
            root.new_edge(node1,node2);
            root.new_edge(node2,node1);

            root.new_edge(node1,node3);
            root.new_edge(node3,node1);

            root.new_edge(node3,node2);
            root.new_edge(node2,node3);

            root.new_edge(node4,node2);
            root.new_edge(node2,node4);
 
            is_a_line_graph = true;
            return;
          }
          
          if(nr_nodes == 5)
          {
            root.new_edge(node1,node2);
            root.new_edge(node2,node1);

            root.new_edge(node1,node3);
            root.new_edge(node3,node1);

            root.new_edge(node3,node2);
            root.new_edge(node2,node3);

            root.new_edge(node4,node2);
            root.new_edge(node2,node4);

            root.new_edge(node4,node3);
            root.new_edge(node3,node4);
 
            is_a_line_graph = true;
            return;
          }


          if(nr_nodes == 6)
          {
            root.new_edge(node1,node2);
            root.new_edge(node2,node1);

            root.new_edge(node1,node3);
            root.new_edge(node3,node1);

            root.new_edge(node1,node4);
            root.new_edge(node4,node1);

            root.new_edge(node3,node2);
            root.new_edge(node2,node3);

            root.new_edge(node4,node2);
            root.new_edge(node2,node4);

            root.new_edge(node4,node3);
            root.new_edge(node3,node4);
 
            is_a_line_graph = true;
            return;
          }
        } /* end if("is-y-triangle odd") ... */
      } /* end if("is-x-triangle odd") ... */
    } /* end if(adjacent) ... */
  } /* end if(len == 2) ... */


  if(len >= 3)
  {
    /* 
       STEP 5. There is a group "X" of three or more nodes adjacent to both
               "basic_nodes". Look in this group for a node which is not
               adjacent to the other member of the group; this is the  
               cross_node (maybe there is none).
 
               In detail: If we find a node "a" in this group to be 
               nonadjacent to some node "b", then "a" is the first node of "X"
               to be investigated with respect to "b", and we shall suspect
               both "a" and "b" as candidates to be the cross_node, or "a" 
               is not the first node of "X" whose adjacency to "b" is 
               investigated, in which case "a" must be the cross_node.
               In the first case, we need only one more checking:
               the adjacency of "a" to some other node "c" of "X". If "a" is
               adjacent to "c", then "b" is the cross_node else "a" is the 
               cross_node.

    */

    node a, b, c;
    bool cross_node_exists = false;
    list<node> help_adj_list;
    node_set help_adj_set(line_graph);
    list_item list_it2;
    list_it = adj_nodes_list.first();
    b = adj_nodes_list.contents(list_it);
    help_adj_list = line_graph.adj_nodes(b);
    forall(x,help_adj_list) help_adj_set.insert(x);
    list_it2 = adj_nodes_list.succ(list_it);
    a = adj_nodes_list.contents(list_it2);

    if(!help_adj_set.member(a))
    { 
      /* either "a" or "b" is the cross_node: */
      list_it = adj_nodes_list.last();
      c = adj_nodes_list.contents(list_it);
      if(help_adj_set.member(c))
      {
        cross_node = a;
        cross_node_exists = true;
      }
      else
      {
        cross_node = b;
        cross_node_exists = true;
      } /* end if(help_adj_set.member(c)) ... */
    }
    else
    {
      /* "a" and "b" are adjacent; look for another node of "X" to be 
         the  cross_node: 
      */
      forall(x,adj_nodes_list)
        if(!cross_node_exists && (x != a) && 
          (x != b) && !help_adj_set.member(x))
        {
          cross_node = x;
          cross_node_exists = true;
        }
    } /* end if(help_adj_set.member(a)) ... */

    if(cross_node_exists)
    {
      first_number[cross_node] = 1;
      second_number[cross_node] = 3;
      fully_named_nodes.insert(cross_node);
      unnamed_nodes.del(cross_node);
      forall(x,adj_nodes_list)
        if(x != cross_node)
        {
          clique_number++;
          first_number[x] = 2;
          second_number[x] = clique_number;
          fully_named_nodes.insert(x);
          unnamed_nodes.del(x);
          naming_nodes.append(x);
        }
    }
    else
      forall(x,adj_nodes_list)
      {
        clique_number++;
        first_number[x] = 2;        
        second_number[x] = clique_number;
        fully_named_nodes.insert(x);
        unnamed_nodes.del(x);
        naming_nodes.append(x);
      } /* end if(cross_node_exists) ... */
  } /* end if(len >= 3) ... */


  /* 
     STEP 6 and STEP 7 in one Block. Use all nodes in the nodelist
     "naming_nodes" to half_name the adjacent nodes:
  */
  forall(fully_named_node,naming_nodes)
  {
    adj_nodes_list = line_graph.adj_nodes(fully_named_node); 
    forall(x,adj_nodes_list)
      if(!fully_named_nodes.member(x))
        if(unnamed_nodes.member(x))
        {
          half_named_nodes.insert(x);
          unnamed_nodes.del(x);
          first_number[x] = second_number[fully_named_node];
          half_named_from[x] = fully_named_node;
        }
        else
        { 
          /* "x" is a half_named node: */
          half_named_nodes.del(x);
          fully_named_nodes.insert(x);
          second_number[x] = second_number[fully_named_node];
        }
  } /* end forall(fully_named_node,naming_nodes) ... */


  /*
     STEP 8. the main step: choose a new couple of basic_nodes, 
             the first node fully_named, the other one half_named and 
             adjacent to the first one. They and the nodes adjacent to 
             them build the new clique and half_name the the nodes
             adjacent to the clique which are not yet fully_named.
             Repeat this step until all nodes are fully named.
  */ 
  while(half_named_nodes.size() != 0)
  {
    half_named_node = half_named_nodes.choose();
    half_named_nodes.del(half_named_node);
    fully_named_node = half_named_from[half_named_node];
    /* "fully_named_node" is the node which half_named the 
       (adjacent) "half_named_node" */

    clique_number++;
    second_number[half_named_node] = clique_number;
    fully_named_nodes.insert(half_named_node);

    basic_node1 = fully_named_node;
    basic_node2 = half_named_node;

    naming_nodes.clear();
    naming_nodes.append(basic_node1);
    naming_nodes.append(basic_node2);

    adj_nodes_list.clear();
    adj1_set.clear();
    adj2_set.clear();

    adj1_list = line_graph.adj_nodes(basic_node1);
    adj2_list = line_graph.adj_nodes(basic_node2);
    forall(x,adj1_list) adj1_set.insert(x);

	//cross_node = NULL;
    forall(x,adj2_list)
    {
      adj2_set.insert(x);
      if(adj1_set.member(x)
		 && (x != cross_node) 
         && !fully_named_nodes.member(x))
         adj_nodes_list.append(x);
    } /* end forall(x,adj2-list) ...   */

    /* "adj_nodes_list" is now the list containing all nodes adjacent to 
       both "basic_nodes"  */

    forall(x,adj_nodes_list)
    {
      clique_number++;
      second_number[x] = clique_number;
      half_named_nodes.del(x);
      fully_named_nodes.insert(x);
      naming_nodes.append(x);
    }

    forall(fully_named_node,naming_nodes)
    {
      adj_nodes_list = line_graph.adj_nodes(fully_named_node);
      forall(x,adj_nodes_list)
        if(!fully_named_nodes.member(x))
          if(unnamed_nodes.member(x))
          {
            half_named_nodes.insert(x);
            unnamed_nodes.del(x);
            first_number[x] = second_number[fully_named_node];
            half_named_from[x] = fully_named_node;
          }
          else
          { 
            /* "x" is a half_named node: */
            half_named_nodes.del(x);
            fully_named_nodes.insert(x);
            second_number[x] = second_number[fully_named_node];
          }
    } /* end forall(fully_named_node,naming_nodes) ... */
  } /* end while( ...) */



  /* STEP 9. the last step; decide wether the graph "line_graph" H
             is really a line graph or not. 
             Create the root graph "root", from the two arrays "first_number" 
             and "second_number". At this Point, the only wrong thing that 
             can happen is that there are parallel edges in the "root" 
             and "line_graph" is not a line graph: exit! 
             Else create the graph L(G), in the program named as "L". This 
             is done in a way which preserves the optimality of the algorithm.
             With this creation is also constructed the node_matrix "iso_check",
             which preserves explicitly the connections between the nodes of 
             "L".
             Then, the next step is to check the number of edges in both graphs,             "line_graph" and "L".
             If they are NOT equal, then exit -- "line_graph" is not a line 
             graph, the choice of the name was to optimistic, hrmm ... .
             If they are equal, it is still necessary to check if there exists
             an isomorphism between the two graphs:
                Check for each edge in in "line_graph", wether or not the
                corresponding edge in "L" exists. This is easy possible using
                the node_matrix "iso_check" mentioned above. The correspondence
                between the nodes of "L" and "line_graph" is known by the 
                node_array(node) "correspondent_node".
             If NO, then again "line_graph" is not a line graph.
             If YES, "line_graph" is definitly a line graph!                                       
  */
 
  GRAPH<int,int> L;
  node_array<node> correspondent_node(line_graph);
  array2<node> root_nodes_give_a_line_graph_node(0,clique_number,0,clique_number);

  int i, j, n, first, second;

  /* Create the root graph "root": if "root" has paralell edges or slings, 
     then "line_graph" is not a line graph! Exit.
  */


  array<node> root_node_array(1,clique_number);
  is_a_line_graph = true;
  n = 1;
  while(n <= clique_number)
  {
    x = root.new_node(n);
    root_node_array[n] = x;
    n++;
  }

  node_matrix<int> test_for_double_edge(root,0);
  forall_nodes(x,line_graph)
  {
    first = first_number[x];
    second = second_number[x];
    if(first == second)
    {
      is_a_line_graph = false;
      return; 
      /* "root" has a sling (an edge (x,x)); 
          it can't be the root of a line graph ! */
    }
    root_nodes_give_a_line_graph_node(first,second) = x;
    root_nodes_give_a_line_graph_node(second,first) = x;
    u = root_node_array[first];
    v = root_node_array[second];
    root.new_edge(u,v);
    root.new_edge(v,u);
    test_for_double_edge(u,v)++;
    if(test_for_double_edge(u,v) > 1) 
    {
      is_a_line_graph = false; 
      return;
      /* "root" has parallel edges; it can't be the root of a line graph ! */
    }
  }

  
  edge_array<node> root_edge_gives_L_node(root);
  edge_array<edge> reverse_edge(root);

  /* create the reverse edge for every edge: */
  forall_edges(e,root)
  {
    x = root.source(e);
    y = root.target(e);
    forall_adj_edges(e1,y)
      if(root.target(e1) == x)
      {
        reverse_edge[e1] = e;
        reverse_edge[e] = e1;
      }
  }

  /* 
    1. Create the correspondence between the edges of "root" and the 
       nodes of "L";
    2. Create the correspondence between the nodes of "line_graph" and the 
       nodes of "L" (with the array "correspondent_node"):
  */

  forall_edges(e,root)
  {
    i = root.inf(root.source(e));
    j = root.inf(root.target(e));
    if(i < j)
    {
      x = root_nodes_give_a_line_graph_node(i,j);
      y = L.new_node(line_graph.inf(x));
      root_edge_gives_L_node[e] = y;
      e1 = reverse_edge[e];
      root_edge_gives_L_node[e1] = y;
      correspondent_node[x] = y;     
    }
  } 

  /* 
    1. Create the edges in "L" by iterating through the edges of "root" and 
       making use of the prepared edge-node correspondence;
    2. Prepare the isomorphism-check by filling the node_matrix "iso_check:

  */

  node_matrix<int> iso_check(L,0);

  forall_edges(e,root)
  {
    u = root_edge_gives_L_node[e]; 
    /* "u" is the node of "L" which corresponds to "e" */

    x = root.source(e);
    forall_adj_edges(e1,x)
      if(e1 != e)
      {
        v = root_edge_gives_L_node[e1];
        /* "v" is the node of "L" which corresponds to "e1" */

        L.new_edge(u,v);
        iso_check(u,v)++;
      }
  } /* "L", the line graph of the root graph "root", is now created  */
 
  if(L.number_of_edges() != nr_edges)
  {
    is_a_line_graph = false;
    return;
  } /* the number of edges in "line_graph" and "L" are different: "line_graph" is not a line graph !  */
  


  /* else: check isomorphism: */
  forall_edges(e,line_graph)
  {
    u = line_graph.target(e);
    v = line_graph.source(e);

    x = correspondent_node[u];  /* "x" and "y" are nodes of the graph "L" */ 
    y = correspondent_node[v];

    if(iso_check(x,y) != 1)
    {
      is_a_line_graph = false;
      return;
    } /* "line_graph" and "L" had accidently the same number
          of edges (and nodes of course),
          but they are NOT isomorphic, hence "line_graph" is
          NOT a line graph  !
      */ 
  }


  /* the graph is a line graph: */

  is_a_line_graph = true;
  n = 0;
  forall_nodes(x,root)
  {
    root.assign(x,n);
    n++;
  } /* the nodes are numbered from 0 on */
} /* end LEHOT */