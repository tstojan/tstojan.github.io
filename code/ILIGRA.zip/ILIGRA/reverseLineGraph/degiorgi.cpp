/* 
   This is an implementation of an algorithm due to Daniele Degiorgi
   to detect line graphs, described in 

     Technischer Bericht, Institut f\"ur Theoretische Informatik, 
     ETH Z\"urich, 1990. 
     
   "A New Linear Algorithm to Detect a Line Graph and Output Its Root Graph" 

   Implementation by Hans-Peter Schmocker, III C/Diplomsemester, ETH Zurich.
   Date of last change: 27.February 1991

   The main procedure is called DEGIORGI.
   It uses directly three other important procedures
   called "initialize", "expand" and "minimal node cover".
   These again use the procedures "two_colouring", "one_colour_node_cover",
   "create_second_root" and "transfer".
*/

#include <LEDA/graph/graph.h>
#include <LEDA/graph/node_data.h>
#include <LEDA/core/array.h>
#include <LEDA/graph/node_set.h>
#include <LEDA/graph/edge_set.h>
#include <LEDA/graph/node_matrix.h>
#include <LEDA/system/basic.h>
#include "common.cpp"

/* 
   The procedure "two_colouring" checks, wether the graph "gr" is 
   two-colourable or not; it explores the graph just like a Breadth 
   First Search; hence, the complexity is O(|V| + |E|).
   "gr" should be connected, otherwise just one component of
   the graph is explored (the component containing the first node).
   In our application, we need this procedure in a case (in the
   procedure "minimal_node_cover") where the graph is connected.
       The boolean value "two_colourable" is "true", if the graph is 
   two_colourable; in this case, the node_array(int)& "colouring" 
   contains the colour of each node of "gr".
       The graph exploration starts with the node "start_node".
*/

static void scc_dfs(const graph& G, node v, node_array<int>& compnum,
                                     node_array<int>& dfsnum,
                                     list<node>&      unfinished,
                                     list<node>&      roots,
                                     node_array<bool>& in_unfinished,
                                     int& count1, int& count2 )
{
  node w;

  dfsnum[v] = ++count1;
  in_unfinished[v] = true;
  unfinished.push(v);
  roots.push(v);

  forall_adj_nodes(w,v,G)
    { if (dfsnum[w]==-1) 
       scc_dfs(G,w,compnum,dfsnum,unfinished,roots,in_unfinished,count1,count2);
      else 
       if (in_unfinished[w])
        while (dfsnum[roots.head()]>dfsnum[w])  roots.pop();
     }

  if (v==roots.head()) 
   { do { w=unfinished.pop();
          /* w is an element of the scc with root v */
          in_unfinished[w] = false;
          compnum[w] = count2;
         } while (v!=w);
     count2++;
     roots.pop(); 
    }
}

static int STRONG_COMPONENTS(const graph& G, node_array<int>& compnum)
{
  // int STRONG_COMPONENTS(graph& G, node_array(int)& compnum)
  // computes strong connected components (scc) of digraph G
  // returns m = number of scc 
  // returns in node_array(int) compnum for each node an integer with
  // compnum[v] = compnum[w] iff v and w belong to the same scc
  // 0 <= compnum[v] <= m-1 for all nodes v

  list<node>       unfinished;
  list<node>       roots;
  node_array<bool> in_unfinished(G,false);
  node_array<int>  dfsnum(G,-1);

  int count1 = 0; 
  int count2 = 0;

  node v;

  forall_nodes(v,G) 
      if (dfsnum[v] == -1) 
       scc_dfs(G,v,compnum,dfsnum,unfinished,roots,in_unfinished,count1,count2);

  return count2;
}

static void two_colouring (bool& two_colourable, 
                    node_array<int>& colouring, 
                    GRAPH<int,int>& gr, 
                    node& start_node)
{
  list_item list_it;
  node x,y;
  list<node> L;
  int colour = 1; 
  two_colourable = true;
  forall_nodes(x,gr) colouring[x] = 2;
  colouring[start_node] = colour;
  L.append (start_node);
 
  while((L.length() != 0) && two_colourable)
  {
    list_it = L.first();
    x = L.contents(list_it);
    colour = 1 - colouring[x];
    L.del(list_it);
    forall_adj_nodes(y,x,gr)
      if(colouring[y] == 2)
      { 
        colouring[y] = colour;
        L.append(y);  
      }
      else
        if(colouring[x] == colouring[y]) 
          two_colourable = false;
  } /* end while .. */
} /* end two_colouring ... */


/* 
   The small procedure "expand" is used to expand the graph "root".
   There are two cases: 
   1. the cover contains one node: create a new node and an edge between the 
       cover node and the new node. 
   2. the cover contains two nodes: create a new edge between these two 
       cover nodes.

    "n" is the current number of nodes of the root graph, 
    "correspondent_node" is the node for which we search 
    the correspondent edge of the root graph, "f_array" is the correspondence.
    This procedure is used by "initialize" and "DEGIORGI".
*/
static void expand(GRAPH<int,int>& root, 
            list<node>& cover, 
            node_array<edge>& f_array, 
            int& n, 
            node& correspondent_node)
{
  node i, j, new_n;
  edge e;
  list_item list_it;

  if(cover.length() == 1)
  {
    list_it = cover.first();
    i = cover.contents(list_it);
    new_n = root.new_node(n); n++; /*   a new node is created and connected   */
    e = root.new_edge(i,new_n);   /*   with the only cover node "i"          */
    root.new_edge(new_n,i);
    f_array[correspondent_node] = e;
  }

  if(cover.length() == 2)
  {
    list_it = cover.first();
    i = cover.contents(list_it);
    list_it = cover.last();
    j = cover.contents(list_it); 
    /* the two cover nodes "i" and "j" are connected. */
    
    e = root.new_edge(i,j); 
    root.new_edge(j,i);
    f_array[correspondent_node] = e; 
  }
} /* end expand( ....) ... */
 

/* the procedure "one_colour_node_cover" is used by "minimal node cover.
   There is a case in which just one component of a created help graph 
   ("S_graph") exists. Then we have to test a colouring with one of
   the two colours.
   This work does "one_colour_node_cover".
*/ 

static void one_colour_node_cover(int& colour, list<node>& cover, 
                           GRAPH<int,int>& S_graph, 
                           node_array<int>& colouring, 
                           node_array<node>& S_node_gives_root_node,
                           GRAPH<int,int>& root_graph)
{
    node s, x, node1, cover_node1, node2, cover_node2;
    edge e;
    bool first_cover_node_is_found = false;
    forall_nodes(s,S_graph)
      if(!first_cover_node_is_found)
        if(colouring[s] == colour)
        {
          x = S_node_gives_root_node[s];
          if(root_graph.indeg(x) == S_graph.indeg(s))
          {
            node1 = s;
            cover_node1 = x;
            first_cover_node_is_found = true;
            cover.append(cover_node1);
          } 
       /* We have found now the first possible cover node with colour == col */
        } /* end forall_nodes(s,S_graph) ... */

/* If we have found a cover node, look for another one with the same colour: */
    
    bool second_cover_node_is_found = false;
    if(first_cover_node_is_found)
      forall_nodes(s,S_graph)
        if(!second_cover_node_is_found)
          if((colouring[s] == colour) && (s != node1))
          {
            x = S_node_gives_root_node[s];
            if(root_graph.indeg(x) == S_graph.indeg(s))
            {
              node2 = s;
              cover_node2 = x;
              second_cover_node_is_found = true;
              cover.append(cover_node2);
            } /* We have found the second cover node with the same colour */
          } /* end if(first_cover_node_is_found) ... */

/* 
 Test now  wether the founded node(s) really cover(s) all edges of "S_graph":
*/
    bool stop = false;
    if(first_cover_node_is_found || second_cover_node_is_found)
      forall_edges(e,S_graph) 
        if(!stop)
        {
          if(first_cover_node_is_found && second_cover_node_is_found)
            /*  "node1" respective "node2" in "S_graph" correspond to 
                "cover_node1" respective "cover_node2" in "root"
            */
            if(!((S_graph.source(e) == node1) || (S_graph.source(e) == node2) ||
                 (S_graph.target(e) == node1) || (S_graph.target(e) == node2)))
                 {
                   cover.clear();   
                   stop = true;                 /*    
                   There is an edge "e" in "S_graph"  which is covered 
                   neither by "node1" nor "node2"       */
                 }

          if(first_cover_node_is_found && !second_cover_node_is_found)
            if(!((S_graph.source(e) == node1) || (S_graph.target(e) == node1)))
                 {
                   cover.clear();   
                   stop = true;             /*    
                   There is an edge "e" in "S_graph"  which is covered 
                   neither by "node1" nor "node2"       */
                 }
        } /* end if(first_cover_node_is_found || second_cover_node_is_found) */
}

/* The procedure "minimal_node_cover" gives us one (or maybe two, 
   in the initialization step) minimal node cover T, |T| <= 2, which
   covers all the edges of a certain graph "S_graph". This graph is
   build inside the procedure by using the edges in the edgelist"S".
   This edges are a subset of all edges from a graph "root_graph" 
   which we build up successivly to be the root of a line graph. 
       The integer "size1" and the nodelist "cover1" are the size respectivly 
   the nodes of the first cover, if there is (in the initialization
   step) another cover, its in the nodelist "cover2" with its size "size2".
   But if just one cover is found, it is in every case in "cover1" !!
       The boolean value "ok" becomes "false", if no appropriate cover can 
   be found. The "cover1" and "cover2" are then empty, "size1" and "size2"
   are zero. This means that "root_graph" is not the root of a line graph;
   the whole algorithm DEGIORGI can terminate.
*/

static void minimal_node_cover(list<node>& cover1, 
                        list<node>& cover2, 
                        bool& ok, 
                        list<edge>& S, 
                        GRAPH<int,int>& root_graph)
{
  GRAPH<int,int> S_graph;
  node_array<node> root_node_gives_S_node(root_graph);
  node_set S_nodes(root_graph);
  node s, t, x, y, cover_node1, cover_node2;
  edge e;
  bool first_cover_node_is_found = false;
  bool second_cover_node_is_found = false;
  cover1.clear();
  cover2.clear();
  int i = 0;

  /* create a graph ("S_graph") using the edges in "S": */
  forall(e,S)
  {
    s = root_graph.source(e);
    t = root_graph.target(e);
    if(!S_nodes.member(s))
    {
      S_nodes.insert(s);
      i = root_graph.inf(s);
      x = S_graph.new_node(i);
      root_node_gives_S_node[s] = x;
    }
    if(!S_nodes.member(t))
    {
      S_nodes.insert(t);
      i = root_graph.inf(t);
      x = S_graph.new_node(i);
      root_node_gives_S_node[t] = x;
    }
  }

  node_array<int> colouring(S_graph);
  node_array<int> comp_num(S_graph);

  node_array<node> S_node_gives_root_node(S_graph);
  forall_nodes(x,root_graph)
    if(S_nodes.member(x))
    {
      s = root_node_gives_S_node[x];
      S_node_gives_root_node[s] = x;
    }

  forall(e,S)
  {
    s = root_graph.source(e);
    t = root_graph.target(e);
    x = root_node_gives_S_node[s];
    y = root_node_gives_S_node[t];
    S_graph.new_edge(x,y); 
    S_graph.new_edge(y,x);        /* S_graph is quasi undirected */
  } /* end forall_edges ... */
/* Test the number of nodes and edges of S_graph : */

  int nr_nodes = S_graph.number_of_nodes();
  int nr_edges = S_graph.number_of_edges()/2;
  if(!(((nr_edges + 4)/2 <= nr_nodes) && (nr_edges + 2 >= nr_nodes)))
  {
    ok = false;
    return;
 }

  int c = STRONG_COMPONENTS(S_graph,comp_num);

  if(c > 2)
  {
    ok = false;
    return;
  } /* S_graph has to much components to be a line graph */

  if(c == 2)
  {
    int nodes_in_first_component = 0;
    int nodes_in_second_component = 0;
    int edges_in_first_component = 0;
    int edges_in_second_component = 0;

    /* count the edges in both components: */
    forall_edges(e,S_graph)
    {
      s = S_graph.source(e);
      if(comp_num[s] == 0) edges_in_first_component++;
      else edges_in_second_component++;
    }  
    edges_in_first_component = edges_in_first_component/2;
    edges_in_second_component = edges_in_second_component/2;
    /* edges were counted twice */
    
    /* count the nodes in both components: */
    forall_nodes(x,S_graph)
      if(comp_num[x] == 0) nodes_in_first_component++;
      else nodes_in_second_component++;

    /* check these numbers in both components: */
    if((nodes_in_first_component - 1 != edges_in_first_component) ||
       (nodes_in_second_component - 1 != edges_in_second_component))
      { 
        ok = false;
        return;
      } /* the graph is not a line graph */

    forall_nodes(s,S_graph)
    {
      /* check the first component ( == the nodes with "comp_num[s] == 0") */
      if((comp_num[s] == 0) && (S_graph.indeg(s) == edges_in_first_component))
      {
        x = S_node_gives_root_node[s];
        /* "x" is the correspondent node of  "s" in root_graph */
        if(root_graph.indeg(x) == S_graph.indeg(s))
        {
          cover_node1 = x;
          first_cover_node_is_found = true;
        }
     } /* if it exists, "cover_node1" is the cover node of the first 
           component, else "S_graph" is not a line graph */

      /* check the second component ( == the nodes with "comp_num[s] == 1") */
      if((comp_num[s] == 1) && (S_graph.indeg(s) == edges_in_second_component))
      {
        x = S_node_gives_root_node[s];
        /* "x" is the correspondent node of "s" in root_graph */
        if(root_graph.indeg(x) == S_graph.indeg(s))
        {
          cover_node2 = x;
          second_cover_node_is_found = true;
        }
     } /* if it exists, "cover_node2" is the cover node of the second 
           component, else "S_graph" is not a line graph */
    } /* end forall_nodes(x,S_graph) .. */

    if(!first_cover_node_is_found || !second_cover_node_is_found)
    {
      ok = false;
      return;
    }
    else
    {
      ok = true;
      cover1.append(cover_node1);
      cover1.append(cover_node2);
      //forall_adj_nodes(x,cover_node1,S_graph)
	  forall_nodes(x,S_graph)
		  if(S_graph.adj_nodes(cover_node1).search(x))
        if(x == cover_node2) ok = false;
       /* this pair of nodes is in "root" already connected ! */

      return; /* Because "S_graph" has two components, there 
                 is only cover: "cover1", 
                (if "S_graph" is a line graph at all!)*/
    }
  } /* end if(c == 2) .. */

  if(c == 1)
  {
    s = S_graph.first_node();
    two_colouring(ok,colouring,S_graph,x);
    if(!ok) return; 
    /* "S_graph" is not two colourable, hence not a line graph!
       Else: "S_graph" is two colourable and connected:
             Look for the minimal node cover by using two nodes 
             of the same colour:
    */
    int colour = 0;
    one_colour_node_cover(colour,cover1,S_graph,colouring,
                          S_node_gives_root_node,root_graph);
    colour = 1;
    one_colour_node_cover(colour,cover2,S_graph,colouring,
                          S_node_gives_root_node,root_graph);
    if((cover1.length() == 0) && (cover2.length() == 0)) 
    {
      ok = false; 
      return;
    }
    else ok = true; 
    /* ok = true: the graph "root_graph" is still the root of a line graph */
    if(cover1.length() == 0)
    {
      cover1 = cover2; 
      cover2.clear();   /*  
      if "cover1" is empty, but "cover2" NOT, then transfer the contents, 
      for that the only cover is always in "cover1".  */
     } /* end if((cover1.length() == 0) && (cover2.length() != 0)) .. */
  } /* end if(c == 1) ... */
} /* end minimal_node_cover ... */




/*   The procedure "create_second_root" is used in the initialization step;
     there is possibility of two graphs; hence the current "root" must be
     copied with the same correspondence. Then is the first expansion made
     with the corresponding nodes of "second_root".
*/

static void create_second_root(GRAPH<int,int>& second_root, 
                        node_array<edge>& second_f,
                        GRAPH<int,int>& root, 
                        node_array<edge>& f,
                        list<node>& cover2,
                        node& assigned_node,
                        list<node>& assigned_nodes_list)
{
  node_array<node> copy_node(root);
  edge_array<edge> copy_edge(root);
  node x, x2, y, y2, src, trgt;
  edge e1, e2;
  list_item list_it;
  int i = 0; 
  
  forall_nodes(x,root)
  {
    i = root.inf(x);
    x2 = second_root.new_node(i);
    copy_node[x] = x2;
  }
  
  forall_edges(e1,root)
  {
    src = root.source(e1);
    trgt = root.target(e1);
    e2 = second_root.new_edge(copy_node[src],copy_node[trgt]);
    copy_edge[e1] = e2;
  }

  forall(x,assigned_nodes_list)
    if(x != assigned_node)
    {
      e1 = f[x];
      e2 = copy_edge[e1];
      second_f[x] = e2;
    }
  /* "second_root" is now identical with "root", even the correspondence
     between the edges and the nodes of "line_graph" is the same.
     But: now, "second_root" makes an other expansion as "root" because
          "second_root" uses the other cover ("cover2") :
  */
  int n2 = second_root.number_of_nodes();
  if(cover2.length() == 1)
  {
    list_it = cover2.first();
    x = cover2.contents(list_it);
    x2 = copy_node[x];
    cover2.clear();
    cover2.append(x2);
    expand(second_root, cover2, second_f, n2, assigned_node);
  }

  if(cover2.length() == 2)
  {
    list_it = cover2.first();
    x = cover2.contents(list_it);
    x2 = copy_node[x];
    list_it = cover2.last();
    y = cover2.contents(list_it);
    y2 = copy_node[y];
    cover2.clear();
    cover2.append(x2);
    cover2.append(y2);
    expand(second_root, cover2, second_f, n2, assigned_node);
  }
} /* end create_second_root .. */
 


         
/* the procedure "transfer" is used in the initialization step. 
   There is a situation possible, where "root" becomes empty, but not
   "second_root". Then we change that; we make "root" a copy of 
   "second_root" and clear "second_root" for that "root" is always
   in a proper state and finally, "root" is returned to "DEGIORGI".
*/       
                       
static void transfer(GRAPH<int,int>& root,
              node_array<edge>& f,
              GRAPH<int,int>& second_root, 
              node_array<edge>& second_f,
              list<node>& assigned_nodes_list)
{
  node_array<node> copy_node(second_root);
  edge_array<edge> copy_edge(second_root);
  node x, y, src, trgt;
  edge e1, e2;
  int i = 0;
  /* precondition is : "root" is an empty graph */

  forall_nodes(x,second_root)
  {
    i = second_root.inf(x);
    y = root.new_node(i);
    copy_node[x] = y;
  }
  
  forall_edges(e1,second_root)
  {
    src = second_root.source(e1);
    trgt = second_root.target(e1);
    e2 = root.new_edge(copy_node[src],copy_node[trgt]);
    copy_edge[e1] = e2;
  }

  forall(x,assigned_nodes_list)
  {
    e1 = second_f[x];
    e2 = copy_edge[e1];
    f[x] = e2;
  }
  second_root.clear();
} /* end transfer */

/*   
     The procedure "initialize" should intitialize the algorithm in such 
     a way that "root" contains five nodes and at most seven edges to make 
     use of whitney's theorem, that says: 
         if there are two connected edge isomorphic graphs with 
         more than four nodes, than these graphs are node isomorphic
         and there exists exactly one node isomorphism which generates  
         the given edge isomorphism.
     That means that in the initialization step, it is possible, that -- at 
     some point -- two different appropriate covers are found. If this happens,
     then we should maintain two graphs until in one of the graphs, a desired
     edge can't be inserted. This graph can be discarded.
        The parameters are the possible line graph "line_graph", 
     the boolean value "decided" which returns the information whether 
     detection is already done (in a positiv or negativ sense),
     the node "start_node", the boolean value "is_a_line_graph", 
     the graph "root",
     the node_set "assigned_nodes" which contains all already assigned nodes,
     the  node_set "unassigned_neighbour_nodes" which contains all unassigned
     nodes neighboured to assigned nodes and the node_array(edge) "f" which 
     preserves the correspondence between the nodes of "line_graph" and
     the edges of "root".   
*/ 


static void initialize(GRAPH<int,int>& line_graph, 
                bool& decided, 
                node& start_node, 
                bool& is_a_line_graph, 
                GRAPH<int,int>& root, 
                node_set& assigned_nodes, 
                node_set& unassigned_neighbour_nodes, 
                node_array<edge>& f)
{
  node_array<edge> second_f(line_graph);
  decided = false;
  bool two_roots_now = false; 
  list<edge> S, S2;
  list<node> cover1, cover2, assigned_nodes_list;

  int n, n2;
  edge e;
  node x, y, z, assigned_node;
  GRAPH<int,int> second_root;

  n = 0;  /* "n" count the number of nodes of "root" */
 
  /* create the first edge of the root graph: */
  x = root.new_node(n); n++;
  y = root.new_node(n); n++;
  e = root.new_edge(x,y); 
  root.new_edge(y,x);

  /* assign the first node of "line graph" to the first edge of "root": */
  f[start_node] = e;
  assigned_nodes.insert(start_node);
  assigned_nodes_list.append(start_node);
  forall_adj_nodes(x,start_node,line_graph) unassigned_neighbour_nodes.insert(x);
  if(unassigned_neighbour_nodes.size() == 0)
  {
    decided = true;
    is_a_line_graph = true;
    return;
  }  /* "root" is:    (u)------(v)   */
  /* else: */
  assigned_node = unassigned_neighbour_nodes.choose();
  unassigned_neighbour_nodes.del(assigned_node);
  assigned_nodes.insert(assigned_node);
  assigned_nodes_list.append(assigned_node);

  /* create the third root_node and the second root_edge; 
    assign this edge to the second line_graph_node "assigned_node" :   */
  z = root.new_node(n); n++;
  e = root.new_edge(y,z); 
  root.new_edge(z,y);
  f[assigned_node] = e;

  /* update the neighbourhood of the assigned nodes: */
  forall_adj_nodes(x,assigned_node,line_graph)
    if((x != start_node) && !unassigned_neighbour_nodes.member(x))
      unassigned_neighbour_nodes.insert(x);
  if(unassigned_neighbour_nodes.size() == 0)
  {
    decided = true;
    is_a_line_graph = true;
    return;
  } /* "root" is:    (u)------(v)-------(w)   */
  /* else : go ahead */
  S.clear();
  assigned_node = unassigned_neighbour_nodes.choose();
  unassigned_neighbour_nodes.del(assigned_node);
  assigned_nodes.insert(assigned_node);
  assigned_nodes_list.append(assigned_node);
  forall_adj_nodes(x,assigned_node)
  {
    if(!assigned_nodes.member(x) && !unassigned_neighbour_nodes.member(x))
      unassigned_neighbour_nodes.insert(x);
    if(assigned_nodes.member(x))
    {
      e = f[x];
      S.append(e);
    }
  } /* end forall_adj_nodes(x, ... */

  /* now look for the minimal node cover T, (|T| <= 2) ;
    just like mentioned above, it's possible that two covers are found;
    then we should maintain two graphs, until one of them is out of the race
    (i.e. it's not possible to insert a desired edge any more
  */
  minimal_node_cover(cover1, cover2, is_a_line_graph, S, root);
  if(!is_a_line_graph) 
  {
    decided = true;
    return;
  }
  /* "line_graph" was the graph K_(1,3), the first forbidden graph */

  if((cover1.length() != 0) && (cover2.length() != 0)) 
  /* two appropriate covers are found: */
  {
    two_roots_now = true;
    create_second_root(second_root, second_f, root, f, cover2, 
                       assigned_node, assigned_nodes_list); 
    n2 = second_root.number_of_nodes();
  }                                           /* the second root is created, */
  expand(root, cover1, f, n, assigned_node); /* "root" is expanded          */

 
  while((root.number_of_edges() < 14) || (root.number_of_nodes() < 5))
  { 
    if(unassigned_neighbour_nodes.size() == 0)
    {
      decided = true;
      is_a_line_graph = true;
      return;
    }
    /* else go ahead: */
    assigned_node = unassigned_neighbour_nodes.choose();
    unassigned_neighbour_nodes.del(assigned_node);
    assigned_nodes.insert(assigned_node);
    assigned_nodes_list.append(assigned_node);
    S.clear();
    S2.clear();
    /* look for the assigned neighbour nodes in "line_graph" respectivly the 
       corresponding edges in "root": */
    forall_adj_nodes(x,assigned_node,line_graph)
    {
      if(!assigned_nodes.member(x) && !unassigned_neighbour_nodes.member(x))
        unassigned_neighbour_nodes.insert(x);
      if(assigned_nodes.member(x))
      {
        e = f[x];
        S.append(e);
        if(two_roots_now)
        {
          e = second_f[x];
          S2.append(e);
        }
      }
    } /* end forall_adj_nodes(x,d) ... */

    if(!two_roots_now)
    {
      minimal_node_cover(cover1, cover2, is_a_line_graph, S, root);
      if(!is_a_line_graph) 
      {
        decided = true;
        return;
      }
      if((cover1.length() != 0) && (cover2.length() != 0))
      { 
        two_roots_now = true;
        create_second_root(second_root, second_f, root, f, cover2, 
                           assigned_node, assigned_nodes_list);
        n2 = second_root.number_of_nodes();
      }
      expand(root, cover1, f, n, assigned_node);
    }   
    else /* two roots alive: */
    {
      minimal_node_cover(cover1, cover2, is_a_line_graph, S, root);
      if(!is_a_line_graph) 
      {
        root.clear();
        two_roots_now = false;
      } /* the original root is deleted */
      else
        expand(root, cover1, f, n, assigned_node);
      minimal_node_cover(cover1, cover2, is_a_line_graph, S2, second_root);
      if(!is_a_line_graph) 
        if(!two_roots_now)
        {
          decided = true;
          return;
        } /* to both root graphs were no appropriate cover found ! */
      if(!is_a_line_graph && two_roots_now) 
      {
        second_root.clear();
        two_roots_now = false;
      } /* the second root is deleted */

      if(is_a_line_graph) 
        expand(second_root, cover1, second_f, n2, assigned_node);
      if(!two_roots_now && (root.number_of_edges() == 0))
      {
        transfer(root, f, second_root, second_f, assigned_nodes_list);
        n = n2;
      }
    } /* end if(!two_roots_now) ... */
  } /* end while( .. )  */

  is_a_line_graph = true;
  decided = false;

} /* end "initialize" */
   
 
     
/* 
     The procedure "DEGIORGI" gives the root "root_graph" of a graph, 
     if this graph is a line graph.
*/

static void DEGIORGI(GRAPH<int,int>& line_graph, node& start_node, 
              bool& is_a_line_graph, GRAPH<int,int>& root)
{
  node_set assigned_nodes(line_graph);
  list<node> cover, dummy_cover;
  node_set unassigned_neighbour_nodes(line_graph);
  node_array<edge> f(line_graph);
  node u, v;
  edge e;
  list<edge> S;

  is_a_line_graph = false;
  int n;
  bool already_decided = false;
  initialize(line_graph, already_decided, start_node, is_a_line_graph, root, 
              assigned_nodes, unassigned_neighbour_nodes, f);
  if(already_decided) return;
  n = root.number_of_nodes();
  while(unassigned_neighbour_nodes.size() != 0)
  {
    v = unassigned_neighbour_nodes.choose();
    S.clear();
    unassigned_neighbour_nodes.del(v);
    assigned_nodes.insert(v);
    forall_adj_nodes(u,v,line_graph)
    {
      if(!assigned_nodes.member(u) &&
         !unassigned_neighbour_nodes.member(u))
                    unassigned_neighbour_nodes.insert(u);
      if(assigned_nodes.member(u))
      { 
        e = f[u];
        S.append(e);
      }
    } /* end forall_adj_nodes(u,v) ... */
    minimal_node_cover(cover,dummy_cover,is_a_line_graph,S,root);
    if(!is_a_line_graph) return; /* No appropriate cover was found */
    expand(root, cover, f, n, v); /* "root" is expanded the way the cover is */
  } /* end while ... */
  
  is_a_line_graph = true; /* the graph is a line graph */
} /* end DEGIORGI */  





