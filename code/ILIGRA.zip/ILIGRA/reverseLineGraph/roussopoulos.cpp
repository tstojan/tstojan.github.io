/*
   This is an implementation of an algorithm due to N.D.Roussopoulos
   to detect line graphs, described in the 
          INFORMATION PROCESSING LETTERS 2, (1973) 108-112,
          NORTH-HOLLAND PUBLISHING COMPANY:

   "A max{m,n} ALGORITHM FOR DETERMINING THE GRAPH H FROM ITS LINE GRAPH G",
     
   Nicolas D.ROUSSOPOULOS.

   Implementation by Hans-Peter Schmocker, III C/Diplomsemester, ETH Zurich.
   Date: 13.December 1990

   Remark: the hint "STEP i" in the comments of the program refers to 
           i'th step in the algorithm of the paper.
*/

#include <LEDA/graph/graph.h>
#include <LEDA/graph/node_data.h>
#include <LEDA/core/array.h>
#include <LEDA/graph/node_set.h>
#include <LEDA/graph/edge_set.h>
#include <LEDA/graph/node_matrix.h>
#include <LEDA/system/basic.h>
#include "common.cpp";

static bool odd_triangle_Roussopoulos(list<node> &list1, list<node> &list2, list<node> &list3,
                  node_set &set1, node_set &set2, node_set &set3)
{
  node x;
  forall(x,list1)
    if(!set2.member(x) && !set3.member(x))
      return true;

  forall(x,list2)
    if(!set1.member(x) && !set3.member(x))
      return true;

  forall(x,list3)
    if(!set1.member(x) && !set2.member(x))
      return true;

  forall(x,list1)
    if(set2.member(x) && set3.member(x))
      return true;

  return false;
}

static void ROUSSOPOULOS(GRAPH<int,int>& G, 
                  node& start_node,
                  bool& is_a_line_graph, 
                  GRAPH<int,int>& H) 
{
  //generalLineGraph general;
  /* "G" is possibly a line graph, "H" becomes then its root graph */
  GRAPH<int,int> Help = G;
  list_item list_it;
  list<clique_pointer> temp;
  bool ok, starting_cell_is_found, v_has_changed, u_has_changed;
  edge e;
  node u, v, w, tri_node, help_node, clique_node;
  node_set u_adj(G), v_adj(G), adj_set(G), triangle_set(G);
  list<node> triangles, u_adj_list, v_adj_list, adj_list;

   /* STEP 1 of the algorithm begins here */
 
  starting_cell_is_found = false;
  /* the start_node is given because a random graph may have several components */

  u = start_node;
  /* the trivial graph (one node, zero edges) is considered as a line graph: 
     (to prevent segmentation faults)
  */

  //G.print();
  //cout<<G.indeg(u)<<endl;

  if(G.indeg(u) == 0) 
  {
    is_a_line_graph = true;
    v = H.new_node(0);
    w = H.new_node(1);
    H.new_edge(v,w);
    H.new_edge(w,v);
    return;
  }

  e = G.first_adj_edge(u);
  v = G.target(e);
  u_adj_list = G.adj_nodes(u);
  v_adj_list = G.adj_nodes(v);

  forall(help_node,u_adj_list) u_adj.insert(help_node);

  forall(help_node,v_adj_list) 
  { 
   v_adj.insert(help_node);
   if(u_adj.member(help_node)) triangles.append(help_node);
  }

  int r = triangles.length(); /* r is the number of triangels containing 
                                the edge e = {u, v}   */
  node_set starting_cell_set(G); 
  list<node> starting_cell_list;

  if(r == 0) 
  {
    starting_cell_set.insert(u);
    starting_cell_set.insert(v);
    starting_cell_list.append(u); 
    starting_cell_list.append(v);
    starting_cell_is_found = true;
    /*   the starting_cell is K2 == {u, v}      */ 
  }
 
  if(r == 1)
  {
    list_it = triangles.first();
    tri_node = triangles.contents(list_it);
    adj_list = G.adj_nodes(tri_node);
    ok =true;
    v_has_changed = false;
    u_has_changed = false;
    forall(help_node,adj_list)
      if(ok)
      {
        if(u_adj.member(help_node))
        {
          v = tri_node;
          v_has_changed = true;
          ok = false;
        }
        if(v_adj.member(help_node) && ok)
        {
        u = tri_node;
        u_has_changed = true;
        ok = false;
        }
      } /* end if(ok) ... */
    if(v_has_changed)
    {
      v_adj.clear();
      triangles.clear();
      v_adj_list = adj_list;
      forall(help_node,adj_list)
      {
        v_adj.insert(help_node);
        if(u_adj.member(help_node)) 
        {
          triangles.append(help_node);
          triangle_set.insert(help_node);
        }
      }
      r = triangles.length();
    } /* end if(v_has_changed) ... */
    if(u_has_changed)
    {
      u_adj.clear();
      triangles.clear();
      u_adj_list = adj_list;
      forall(help_node,adj_list)
      {
        u_adj.insert(help_node);
        if(v_adj.member(help_node)) 
        {
          triangles.append(help_node);
          triangle_set.insert(help_node);
        }
      }
      r = triangles.length();
    } /* end if(u_has_changed) */
    if(ok)
    {
      starting_cell_set.insert(u); starting_cell_list.append(u);
      starting_cell_set.insert(v); starting_cell_list.append(v);
      starting_cell_set.insert(tri_node); starting_cell_list.append(tri_node);
      starting_cell_is_found = true;
      /* starting_cell is the K3 = {u, v, tri_node}  */
    } /* end if(ok) ... */
  } /* end if(r == 1) ... */


 /* STEP 2 of the algorithm begins here */

  if(!starting_cell_is_found)
  {
    node x;
    list<node> odd_triangles1, odd_triangles2;
    node_set odd_triangles_set(G);
    forall(tri_node,triangles)
    {
      adj_list = G.adj_nodes(tri_node);
      forall(x,adj_list) adj_set.insert(x);
	  if(odd_triangle_Roussopoulos(adj_list, u_adj_list, v_adj_list, adj_set, u_adj, v_adj))
        if(!odd_triangles_set.member(tri_node))
        {
          odd_triangles_set.insert(tri_node);
          odd_triangles1.append(tri_node);
          odd_triangles2.append(tri_node);
        }         
     } /* end forall(tri_node, ... */
    int s = odd_triangles1.length(); /* s is the number of odd triangles
                                        in G containing e = {u, v}   */ 


    if((r == 2) && (s == 0))
    {
      int n = G.number_of_nodes();
      int m = G.number_of_edges();
      if((n > 3) && (n < 7))
      { 
        if((n == 4) && (m == 10))
        {
          is_a_line_graph = true;
          /* there is just one graph with four nodes and five edges: H1 */                node a, b, c, d;
          a = H.new_node(0);
          b = H.new_node(1);
          c = H.new_node(2);
          d = H.new_node(3);
          H.new_edge(a,b); H.new_edge(b,a);
          H.new_edge(a,c); H.new_edge(c,a);
          H.new_edge(c,b); H.new_edge(b,c);
          H.new_edge(d,b); H.new_edge(b,d);

          return;
        }  /* root respective "H" is:  K3 + {x}  */



        if((n == 5) && (m == 16))
        {
          forall_nodes(help_node,G)
            if(G.indeg(help_node) == 2)
            {
              is_a_line_graph = false;
              return;
            } 

       /* there are only two graphs with five nodes and eight edges.
          H2 has no node of a degree lesser than three, but the other one has.
       */
          is_a_line_graph = true;
          node a = H.new_node(0),
          b = H.new_node(1),
          c = H.new_node(2),
          d = H.new_node(3);
          H.new_edge(a,b); H.new_edge(b,a);
          H.new_edge(a,c); H.new_edge(c,a);
          H.new_edge(c,b); H.new_edge(b,c);
          H.new_edge(d,b); H.new_edge(b,d);
          H.new_edge(c,d); H.new_edge(d,c);

          /* root is: H1  */ 
          return;
        }



        if((n == 6) && (m == 24))
        { 
        /* there are five graphs with six nodes and twelve edges.
           four of them have min_degree == 3. One has min_degree == 4.
           this one is H3, luckily. 
        */
          int min_deg = 10;
          forall_nodes(help_node,G)
            if(G.indeg(help_node) < min_deg)
              min_deg = G.indeg(help_node);
          if(min_deg == 4)     
          {
            is_a_line_graph = true;
            node a = H.new_node(0),
            b = H.new_node(1),
            c = H.new_node(2),
            d = H.new_node(3);
            H.new_edge(a,b); H.new_edge(b,a);
            H.new_edge(a,c); H.new_edge(c,a);
            H.new_edge(c,b); H.new_edge(b,c);
            H.new_edge(d,b); H.new_edge(b,d);
            H.new_edge(c,d); H.new_edge(d,c);
            H.new_edge(a,d); H.new_edge(d,a);

            /* root is: K4  */ 
            return;
          }
          else
          {
            is_a_line_graph = false;
            return;
          } /* G is one of the four graphs mentioned above */
        } 
        else
        {
          is_a_line_graph = false;
          return;
        } /* end  if((n == 6) && (m == 12)) ...
             G has either (n == 4 && m != 5) or (n == 5 && m != 8) 
             or (n == 6 && m != 12)  */
      }
      else
      {
        is_a_line_graph = false;
        return;
      } /*   end if((n > 3) && ...  
             G has (r == 2 && s == 0 ), but (n != 4, 5, 6).  */
    } /* end if((r == 2) && ... */
  

    if((s == r) || (s == r-1))
    {
      node help_node1, help_node2;
      is_a_line_graph = true;
      forall(help_node1,odd_triangles1)
      {
        adj_list = G.adj_nodes(help_node1);
        adj_set.clear();
        forall(help_node,adj_list) adj_set.insert(help_node);
        forall(help_node2,odd_triangles2)
          if(help_node1 != help_node2)
            if(!adj_set.member(help_node2)) is_a_line_graph = false;
            /* not a clique --> G is not a line graph ! */
      } /* end forall(help_node1, ... */

     if(is_a_line_graph)
      {
        starting_cell_is_found = true;
        starting_cell_set.clear();
        starting_cell_set.insert(u); starting_cell_list.append(u);
        starting_cell_set.insert(v); starting_cell_list.append(v);
        forall(help_node,odd_triangles1)
        {
          starting_cell_set.insert(help_node);
          starting_cell_list.append(help_node);
        }
      }
      else
        return; /* not a line graph */
    }
    else
    {
      is_a_line_graph = false;
      return;
    } /* end if((s == r) || (s == r-1)) ... */
  } /* end if(!starting_cell_is_found) ... */


  /* STEP 3 of the algorithm begins here */

  if(starting_cell_is_found)  
  {
    node_array<int> clique_counter(G,0);
    node_array<int> first_clique(G,0);
    node_array<int> second_clique(G,0);
    list<node> current_clique, adj_list1, adj_list2;
    clique_pointer current_clique_ptr;
    edge_set S(G);
    node_set adj_set1(G);
    int clique_index = 1;
    forall(help_node,starting_cell_list)
    {
      forall_adj_edges(e,help_node)
        if(starting_cell_set.member(G.target(e)))
          S.insert(e);
      clique_counter[help_node]++;
      first_clique[help_node] = clique_index;
    }
    while(!S.empty())
    {
      e = S.choose();
      S.del(e);
      G.del_edge(e);
    } /*   the current graph is now G1 == G - starting_cell.  */

    temp.append(&starting_cell_list); 
    while(temp.length() != 0)
    {
      list_it = temp.first();
      current_clique_ptr = temp.contents(list_it);
      current_clique = *current_clique_ptr;
      temp.del(list_it);
      forall(clique_node,current_clique)
        if(G.indeg(clique_node) != 0)
        {
          clique_counter[clique_node]++;
          if(clique_counter[clique_node] > 2)
          {
            G = Help; 
            is_a_line_graph = false;
            return;
          } /* the current clique_node is in more than two cliques. */
          else
          {
            clique_index++;
            second_clique[clique_node] = clique_index;
            adj_set.clear();
            adj_set1.clear();
            adj_list1 = G.adj_nodes(clique_node);
            forall(u,adj_list1)
            {
              adj_set1.insert(u);
              clique_counter[u]++; 
              if(clique_counter[u] == 1) 
                first_clique[u] = clique_index;
              if(clique_counter[u] == 2) 
                second_clique[u] = clique_index;
              if(clique_counter[u] > 2)
              {
                G = Help; 
                is_a_line_graph = false;
                return;
              } /* a node was found contained in more than two cliques! */
            } /* end forall(u, ... */
            is_a_line_graph = true;
            adj_list2 = adj_list1;
            forall(u,adj_list1)
            {
              adj_list = G.adj_nodes(u);
              forall(help_node, adj_list)
                adj_set.insert(help_node);
              forall(v,adj_list2)
                if(u != v)
                  if(!adj_set.member(v))
                    is_a_line_graph = false;
            } /* end forall(u, ... */

            if(!is_a_line_graph) 
            {
              G = Help; 
              return;
            } 
      /* the adjacent nodes of the current clique_node did'nt form a clique! */
            else
            {
              S.clear();
              adj_set1.insert(clique_node);
              adj_list1.append(clique_node);
              forall(u,adj_list1)
                forall_adj_edges(e,u)
                  if(adj_set1.member(G.target(e)))
                    S.insert(e);
              while(!S.empty()) 
              {
                e = S.choose();
                S.del(e);
                G.del_edge(e);
              } /* G(i+1) = G(i) - current_clique. */

              list<node>* new_clique = new list<node>;
              *new_clique = adj_list1;
              temp.append(new_clique);
            } /* end if(!ok) */
          } /* end if(clique_counter[clique_node ... */
        } /* end forall(clique_node,curr ... */
    } /* end while(temp.length() != 0) ... */


 /* STEP 4 of the algorithm begins here */

    if((G.number_of_edges() == 0) && (temp.length() == 0))
    {
      /* 
      G is a line graph ! 
      Create the root graph H from the constructed line partition,
      which is inherently given by the two node_arrays first_clique
      and second_clique.
      */

      int bound = G.number_of_nodes();
      array<node> root_clique_node(0,bound);
      int i,k;
      i = 1; 
      while(i <= clique_index) 
      {
        v = H.new_node(0);         /* create a rootnode v (of type 1) for */
        root_clique_node[i] = v;  /* each cell. v is the i'th rootnode.  */
        i++;
      }
      forall_nodes(u,G)
        if(clique_counter[u] == 1)
        {
          i = first_clique[u];  /* create a rootnode v (of type 2) for   */
          v = H.new_node(i);   /*  each line_graph_node, which is only  */
        }                     /*  in ONE cell.                         */
      /* all nodes of the root graph H are now created. */

      forall_nodes(v,H)
      {
        i = H.inf(v);        
        if(i != 0)
        {
          w = root_clique_node[i];
          H.new_edge(v,w);
          H.new_edge(w,v);
        }
      } /* all edges between nodes of type 2 and their correspondent nodes 
           of type 1 are created */

      forall_nodes(u,G)
        if(clique_counter[u] == 2)
        {
          i = first_clique[u];
          k = second_clique[u];

          v = root_clique_node[i];
          w = root_clique_node[k];
          H.new_edge(v,w); /* all edges between nodes of type 1 are created */
          H.new_edge(w,v);
        }

       /* all edges of the root graph H are now created. */

      i = 0;
      forall_nodes(u,H)
      {
        H.assign(u,i);
        i++;
      }
    } /* end if.. */
    G = Help;
    is_a_line_graph = true;
  } /* end if (starting_cell_is_found) ... */

  return;

} /* end roussopoulos. */



static bool MY_RANDOM_GRAPH(GRAPH<int,int>& ran, int& n, int& m)
{
  /* This procedure creates a random graph, which is undirected and 
     simplicial. "n" is the number of nodes, "m" the number of edges.
     "n" must'nt be zero, "m" should be lesser or equal n*(n-1).
     Maybe, there are finally more components than one.
     Isolated nodes also are allowed. 
     The graph evolves just that way described in the paper
      "ON THE EVOLUTION OF RANDOM GRAPHS" by P. Erdos and A.Renyi,
     Publ. of the Math. Inst. of the Hungarian Ac. of Science, Vol.V, 1960
  */

  list_item list_it, list_it2;
  list<clique_pointer> all_unassigned_edges;
  node x,y,pair_node1,pair_node2;
  ran.clear();
  int ran_nr,a,b;
  if(n == 0) return false;
  if(m > n*(n-1)/2) return false;
  /* too many edges ! (more than the complete graph) */

  int i = 0;
  while(i < n)
  { 
    ran.new_node(i);
    i++;
  }

  node_matrix<int> test(ran,0);
  forall_nodes(x,ran)
    forall_nodes(y,ran)
      if((x != y) && (test(x,y) == 0))
      {
        test(x,y) = 1;
        test(y,x) = 1;
        list<node>* new_pair = new list<node>; 
        new_pair -> append(x);
        new_pair -> append(y);
        all_unassigned_edges.append(new_pair);
      } 
   /*
      Every pair is contained in "all_unassigned_edges" only once,
      hence the length is now n*(n-1)/2.
   */
      
  clique_pointer current_pair_ptr;
  list<node> current_pair;
  int edge_counter = 1;

  leda::random_source rd;
  rd.set_range(a,b);
  //init_random();

  a = 1;
  while(edge_counter <= m)
  {
     b = all_unassigned_edges.length();

	 rd.set_range(a,b);

	 ran_nr = rd.get();//random(a,b);

     i = 1;
     list_it = all_unassigned_edges.first();

     while(i < ran_nr)
     {
       list_it = all_unassigned_edges.succ(list_it);
       i++;
     } /* we are at the right place now */
     current_pair_ptr = all_unassigned_edges.contents(list_it);
     current_pair = *current_pair_ptr;
     list_it2 = current_pair.first();
     pair_node1 = current_pair.contents(list_it2);
     list_it2 = current_pair.last();
     pair_node2 = current_pair.contents(list_it2);
     all_unassigned_edges.del(list_it);
     ran.new_edge(pair_node1,pair_node2);   
     ran.new_edge(pair_node2,pair_node1);
     edge_counter++;
  }

  return true;
}


 
     









