#include <LEDA/graph/graph.h>
#include <LEDA/graph/node_data.h>
#include <LEDA/core/array.h>
#include <LEDA/graph/node_set.h>
#include <LEDA/graph/edge_set.h>
#include <LEDA/graph/node_matrix.h>
#include <LEDA/system/basic.h>
#include <LEDA/numbers/real.h>
#include <iostream>
#include <fstream>
#include <string>


/*
   common libs for all the functions
*/

using namespace leda;
using leda::GRAPH;
using leda::node;
using leda::edge;
using std::cout;
using std::cin;
using std::endl;

typedef list<node>* clique_pointer;